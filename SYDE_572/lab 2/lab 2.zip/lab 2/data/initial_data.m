%Gaussion distribution
nu = 5;
sigma = 1;

%exponential distribution
lambda = 1;

%parzen 2D

k=400;

%errors
J =5;
limit = 20;
