function[min_est,max_est] = Uniform_estimation_1D(data)
min_est = min(data);
max_est = max(data);
end