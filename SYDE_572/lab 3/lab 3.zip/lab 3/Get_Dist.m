function dist = Get_Dist(x,y)
dist = norm(x-y);
end